import { useCallback, useEffect, useRef, useState } from 'react';
import { Capacitor, registerPlugin } from '@capacitor/core';
import { Preferences } from '@capacitor/preferences';
import { Footprints, RefreshCw, Settings2 } from 'lucide-react';
import { api, errorMessage, useApp } from '../lib/app';
import { apiOrigin } from '../lib/native';
import { addDays } from '../../shared/domain';
import { Button } from './ui';

type HealthStatus = { available: boolean; needsUpdate: boolean; granted: boolean };
const Health = registerPlugin<{
  status(): Promise<HealthStatus>;
  requestAccess(): Promise<HealthStatus>;
  readSteps(options: {
    date: string;
    timezone: string;
  }): Promise<{ date: string; steps: number; hasData: boolean; measuredAt: string }>;
  openSettings(): Promise<void>;
}>('FitTrackHealth');

export function HealthConnect() {
  return Capacitor.getPlatform() === 'android' ? <AndroidSteps /> : null;
}
function AndroidSteps() {
  const app = useApp();
  const latest = useRef(app);
  latest.current = app;
  const [status, setStatus] = useState<HealthStatus>();
  const [enabled, setEnabled] = useState(false);
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState('');
  const enabledRef = useRef(false),
    working = useRef(false),
    alive = useRef(true);
  const key = `fittrack-health:${apiOrigin()}:${app.user!.id}`;
  const date = app.state!.today,
    timezone = app.state!.profile.timezone;
  const sync = useCallback(
    async (history = false) => {
      if (working.current || !enabledRef.current || !alive.current) return;
      working.current = true;
      setBusy(true);
      try {
        const current = await Health.status();
        if (!alive.current) return;
        setStatus(current);
        if (!current.granted)
          throw new Error('Step access is not granted. Reconnect Health Connect to continue.');
        for (let offset = history ? 6 : 0; offset >= 0; offset--) {
          const result = await Health.readSteps({ date: addDays(date, -offset), timezone });
          if (!alive.current || !enabledRef.current) return;
          await api.put('/activity/health-connect', result);
        }
        if (!alive.current) return;
        await latest.current.refresh();
        setMessage('Steps synced from Health Connect.');
      } catch (e) {
        if (alive.current) setMessage(errorMessage(e));
      } finally {
        working.current = false;
        if (alive.current) setBusy(false);
      }
    },
    [date, timezone, key],
  );
  useEffect(() => {
    alive.current = true;
    let cancelled = false;
    Promise.all([Health.status(), Preferences.get({ key })])
      .then(([current, preference]) => {
        if (cancelled) return;
        setStatus(current);
        enabledRef.current = preference.value === 'true';
        setEnabled(enabledRef.current);
        if (enabledRef.current) void sync();
      })
      .catch(() => {
        if (!cancelled)
          setMessage('Health Connect needs Android 9 or later and the latest app update.');
      });
    const resume = () => {
      if (document.visibilityState === 'visible') void sync();
    };
    document.addEventListener('visibilitychange', resume);
    const timer = setInterval(resume, 60000);
    return () => {
      cancelled = true;
      alive.current = false;
      clearInterval(timer);
      document.removeEventListener('visibilitychange', resume);
    };
  }, [key, sync]);
  async function connect() {
    setBusy(true);
    setMessage('');
    try {
      const current = await Health.requestAccess();
      setStatus(current);
      if (!current.granted) {
        setMessage(
          'Step access was not granted. You can try again or manage permissions in Health Connect.',
        );
        return;
      }
      await Preferences.set({ key, value: 'true' });
      enabledRef.current = true;
      setEnabled(true);
      await sync(true);
    } catch (e) {
      setMessage(errorMessage(e));
    } finally {
      setBusy(false);
    }
  }
  async function disconnect() {
    enabledRef.current = false;
    setEnabled(false);
    await Preferences.remove({ key });
    setMessage(
      'Sync stopped. Saved step totals remain. Use Health Connect settings to revoke Android permission.',
    );
  }
  const source = app.state!.activity;
  return (
    <div className="health-connect">
      <div className="health-connect-title">
        <Footprints size={22} />
        <div>
          <strong>Android Health Connect</strong>
          <small>
            {enabled && status?.granted
              ? 'Automatic steps · refreshes while Home is open'
              : 'Connect your phone and watch step data'}
          </small>
        </div>
      </div>
      {!enabled && (
        <p>
          Read daily step totals and sync them to this FitTrack account. Connecting replaces manual
          steps for synced days. Distance, active minutes and calories stay unchanged.
        </p>
      )}
      {status?.available === false && (
        <p>
          {status.needsUpdate
            ? 'Install or update Health Connect to sync steps.'
            : 'Health Connect requires a supported Android 9+ phone. Manual tracking remains available.'}
        </p>
      )}
      {source?.stepsSource === 'health_connect' && (
        <p className="hint">
          {source.stepsHasData === false
            ? 'No step records in Health Connect for this day. Enable step sharing in a compatible fitness app or watch; supported phones can also count through Health Connect.'
            : `Last synced ${new Date(source.stepsSyncedAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}`}
        </p>
      )}
      {message && <p role="status">{message}</p>}
      <div className="health-connect-actions">
        {status?.available && (!enabled || !status.granted) && (
          <Button busy={busy} onClick={connect}>
            {enabled ? 'Reconnect steps' : 'Connect Health Connect'}
          </Button>
        )}
        {enabled && status?.granted && (
          <Button variant="secondary" busy={busy} onClick={() => sync(true)}>
            <RefreshCw size={15} />
            Sync now
          </Button>
        )}
        {(status?.available || status?.needsUpdate) && (
          <Button
            variant="ghost"
            onClick={() => Health.openSettings().catch((e) => setMessage(errorMessage(e)))}
          >
            <Settings2 size={15} />
            {status.needsUpdate ? 'Install / update' : 'Permissions'}
          </Button>
        )}
        {enabled && (
          <Button
            variant="ghost"
            onClick={() => disconnect().catch((e) => setMessage(errorMessage(e)))}
          >
            Disconnect
          </Button>
        )}
      </div>
    </div>
  );
}
